from aws_lambda_powertools.event_handler.events_appsync.appsync_events import AppSyncEventsResolver

__all__ = [
    "AppSyncEventsResolver",
]
